# Register your models here.
from django.contrib import admin
from musics.models import Music

admin.site.register(Music)
